<?php
$x = 'dist/2ndflicker.php';
function redirect($url)
{
    header("location: " . $url);
}
redirect($x);
